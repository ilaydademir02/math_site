export default function MathEnv({
  kind,
  title,
  isProof = false,
  children,
}: {
  kind: string;
  title?: string;
  isProof?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={`math-env not-prose${isProof ? " proof" : ""}`}>
      <span className="math-env-label">
        {kind}
        {title ? <span className="math-env-title normal-case tracking-normal"> — {title}</span> : null}
      </span>
      <div className="text-[1.05rem] leading-relaxed text-ink dark:text-night-text">{children}</div>
    </div>
  );
}
