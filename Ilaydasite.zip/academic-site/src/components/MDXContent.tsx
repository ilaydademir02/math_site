"use client";

import { MDXRemote, MDXRemoteSerializeResult } from "next-mdx-remote";
import MathEnv from "./MathEnv";

const components = {
  Definition: (props: any) => <MathEnv kind="Definition" {...props} />,
  Proposition: (props: any) => <MathEnv kind="Proposition" {...props} />,
  Lemma: (props: any) => <MathEnv kind="Lemma" {...props} />,
  Theorem: (props: any) => <MathEnv kind="Theorem" {...props} />,
  Corollary: (props: any) => <MathEnv kind="Corollary" {...props} />,
  Example: (props: any) => <MathEnv kind="Example" {...props} />,
  Proof: (props: any) => <MathEnv kind="Proof" {...props} isProof />,
};

export default function MDXContent({ source }: { source: MDXRemoteSerializeResult }) {
  return (
    <div className="prose prose-lg font-sans prose-headings:font-serif prose-headings:font-medium">
      <MDXRemote {...source} components={components} />
    </div>
  );
}
