import { site } from "@/config/site";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-line dark:border-night-line">
      <div className="mx-auto max-w-content px-6 py-10 text-sm text-ink-faint dark:text-night-soft">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="font-serif text-ink dark:text-night-text">{site.name}</p>
            <p>{site.institution}</p>
          </div>
          <ul className="flex flex-wrap gap-x-5 gap-y-2 font-mono text-xs uppercase tracking-widest">
            <li>
              <a href={`mailto:${site.email}`} className="hover:text-accent dark:hover:text-accent-soft">
                Email
              </a>
            </li>
            <li>
              <a href={site.links.github} className="hover:text-accent dark:hover:text-accent-soft">
                GitHub
              </a>
            </li>
            <li>
              <a href={site.links.googleScholar} className="hover:text-accent dark:hover:text-accent-soft">
                Scholar
              </a>
            </li>
            <li>
              <a href={site.links.orcid} className="hover:text-accent dark:hover:text-accent-soft">
                ORCID
              </a>
            </li>
          </ul>
        </div>
        <p className="mt-6 text-xs">
          © {year} {site.name}. Built with Next.js.
        </p>
      </div>
    </footer>
  );
}
