export default function PageHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="border-b border-line pb-6 dark:border-night-line">
      {eyebrow && (
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-accent dark:text-accent-soft">
          {eyebrow}
        </p>
      )}
      <h1 className="mt-3 font-serif text-3xl font-medium text-ink sm:text-4xl dark:text-night-text">
        {title}
      </h1>
      {description && (
        <p className="mt-3 max-w-2xl text-ink-soft dark:text-night-soft">{description}</p>
      )}
    </div>
  );
}
