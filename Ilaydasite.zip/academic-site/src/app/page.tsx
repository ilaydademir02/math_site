import Link from "next/link";
import { site } from "@/config/site";

export default function Home() {
  return (
    <>
      <section className="grid-backdrop relative border-b border-line dark:border-night-line">
        <div className="mx-auto max-w-content px-6 py-24 sm:py-32">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-accent dark:text-accent-soft">
            {site.role}
          </p>
          <h1 className="mt-4 max-w-2xl font-serif text-4xl font-medium leading-tight text-ink sm:text-5xl dark:text-night-text">
            {site.name}
          </h1>
          <p className="mt-3 text-lg text-ink-soft dark:text-night-soft">{site.institution}</p>

          <ul className="mt-8 flex flex-wrap gap-x-2 gap-y-2 text-sm">
            {site.researchInterests.map((interest) => (
              <li key={interest} className="flex items-center gap-2">
                <span className="rounded-full border border-line px-3 py-1 text-ink-soft dark:border-night-line dark:text-night-soft">
                  {interest}
                </span>
              </li>
            ))}
          </ul>

          <p className="mt-8 max-w-2xl text-base leading-relaxed text-ink-soft dark:text-night-soft">
            {site.introduction}
          </p>

          <div className="mt-10 flex flex-wrap gap-x-6 gap-y-3 font-mono text-xs uppercase tracking-widest">
            <Link href={site.links.cv} className="border-b border-accent text-accent dark:text-accent-soft">
              CV
            </Link>
            <Link href="/research" className="text-ink-soft hover:text-ink dark:text-night-soft dark:hover:text-night-text">
              Research
            </Link>
            <Link href="/publications" className="text-ink-soft hover:text-ink dark:text-night-soft dark:hover:text-night-text">
              Publications
            </Link>
            <a href={site.links.github} className="text-ink-soft hover:text-ink dark:text-night-soft dark:hover:text-night-text">
              GitHub
            </a>
            <a href={site.links.googleScholar} className="text-ink-soft hover:text-ink dark:text-night-soft dark:hover:text-night-text">
              Google Scholar
            </a>
            <a href={site.links.orcid} className="text-ink-soft hover:text-ink dark:text-night-soft dark:hover:text-night-text">
              ORCID
            </a>
            <a href={`mailto:${site.email}`} className="text-ink-soft hover:text-ink dark:text-night-soft dark:hover:text-night-text">
              Email
            </a>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-8 sm:grid-cols-3">
          <Link href="/research" className="group border-t border-ink/20 pt-4 dark:border-night-text/20">
            <h2 className="font-serif text-xl text-ink dark:text-night-text">Research</h2>
            <p className="mt-2 text-sm text-ink-faint dark:text-night-soft">
              Current problems, directions, and areas of interest.
            </p>
          </Link>
          <Link href="/notes" className="group border-t border-ink/20 pt-4 dark:border-night-text/20">
            <h2 className="font-serif text-xl text-ink dark:text-night-text">Notes</h2>
            <p className="mt-2 text-sm text-ink-faint dark:text-night-soft">
              Expository notes, definitions, theorems, and proofs.
            </p>
          </Link>
          <Link href="/publications" className="group border-t border-ink/20 pt-4 dark:border-night-text/20">
            <h2 className="font-serif text-xl text-ink dark:text-night-text">Publications</h2>
            <p className="mt-2 text-sm text-ink-faint dark:text-night-soft">
              Papers, preprints, and abstracts.
            </p>
          </Link>
        </div>
      </section>
    </>
  );
}
