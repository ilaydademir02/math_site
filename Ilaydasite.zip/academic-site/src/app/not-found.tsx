import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-content flex-col items-start px-6 py-32">
      <p className="font-mono text-xs uppercase tracking-widest text-accent dark:text-accent-soft">
        404
      </p>
      <h1 className="mt-3 font-serif text-3xl text-ink dark:text-night-text">Page not found</h1>
      <p className="mt-3 text-ink-soft dark:text-night-soft">
        The page you're looking for doesn't exist, or may have moved.
      </p>
      <Link href="/" className="mt-6 font-mono text-xs uppercase tracking-widest text-accent underline underline-offset-4 dark:text-accent-soft">
        Back home
      </Link>
    </div>
  );
}
