export const teachingInterests = [
  "[Teaching Interest 1 — e.g. Real Analysis]",
  "[Teaching Interest 2 — e.g. Linear Algebra]",
  "[Teaching Interest 3 — e.g. Mathematical Writing]",
];

export const courses = [
  {
    code: "[MATH 101]",
    title: "[Course Title]",
    role: "Instructor of Record",
    term: "[Semester Year]",
    description: "[One or two sentence description of the course and your role.]",
    notesHref: "#",
    problemSetsHref: "#",
  },
  {
    code: "[MATH 201]",
    title: "[Course Title]",
    role: "Teaching Assistant",
    term: "[Semester Year]",
    description: "[One or two sentence description of the course and your role.]",
    notesHref: "#",
    problemSetsHref: "#",
  },
];

export const officeHours = "[Day], [Time]–[Time], [Office Location] (or by appointment)";

export const teachingResources = [
  { label: "[Resource name, e.g. LaTeX template for problem sets]", href: "#" },
  { label: "[Resource name, e.g. Study guide]", href: "#" },
];
