// ─────────────────────────────────────────────────────────────
// SITE CONFIGURATION
// This is the ONE file you need to edit to personalize the site
// with your name, institution, links, and short bio text.
// ─────────────────────────────────────────────────────────────

export const site = {
  name: "[YOUR NAME]",
  role: "Graduate Student in Mathematics",
  institution: "[UNIVERSITY]",
  department: "[DEPARTMENT]",
  advisor: "[ADVISOR]",
  email: "[EMAIL]",

  // Short list shown on the homepage, e.g. ["Differential Geometry", "PDE", "Spectral Theory"]
  researchInterests: [
    "[Research Area 1]",
    "[Research Area 2]",
    "[Research Area 3]",
  ],

  // Homepage introduction. Edit freely — keep it in your own voice.
  introduction:
    "I am a graduate student in mathematics interested in [areas]. My research focuses on [brief description]. I am particularly interested in the connections between [A], [B], and [C].",

  links: {
    cv: "/cv.pdf",
    github: "https://github.com/[YOUR-GITHUB]",
    googleScholar: "https://scholar.google.com/citations?user=[YOUR-ID]",
    orcid: "https://orcid.org/[YOUR-ORCID]",
    arxiv: "https://arxiv.org/a/[YOUR-ARXIV-ID]",
  },

  nav: [
    { href: "/", label: "Home" },
    { href: "/research", label: "Research" },
    { href: "/publications", label: "Publications" },
    { href: "/notes", label: "Notes" },
    { href: "/teaching", label: "Teaching" },
    { href: "/cv", label: "CV" },
    { href: "/about", label: "About" },
  ],

  seo: {
    title: "[YOUR NAME] — Mathematics",
    description:
      "Personal academic website of [YOUR NAME], graduate student in mathematics at [UNIVERSITY].",
  },
};
